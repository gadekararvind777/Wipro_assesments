﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PalindromeString.Services;

namespace PalindromeString.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PalindromeController : ControllerBase
    {
  
        private readonly IPalindromeService _service;

        public PalindromeController(IPalindromeService service)
        {
            _service = service;
        }

        [HttpPost("longestSubstring")]
        public IActionResult GetLongestPalindrome([FromBody] PalindromeModel model)
        {
            try
            {
                if (model.Input == null || string.IsNullOrWhiteSpace(model.Input))
                    return BadRequest("Input string is required.");

                var result = _service.FindLongestPalindromeString(model.Input);
                return Ok(new { longestPalindrome = result });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception)
            {
                return StatusCode(500, "An unexpected error occurred.");
            }
        }
    }
}
