﻿namespace PalindromeString.Services
{
    public interface IPalindromeService
    {
        public string FindLongestPalindromeString(string input);
    }
}
