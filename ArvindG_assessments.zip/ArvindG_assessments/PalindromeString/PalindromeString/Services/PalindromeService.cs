﻿namespace PalindromeString.Services
{
    public class PalindromeService : IPalindromeService
    {
        public string FindLongestPalindromeString(string input)
        {
           
            int start = 0, maxLength = 1;

            for (int i = 0; i < input.Length; i++)
            {
                // Odd length
                ExpandCenter(input, i, i, ref start, ref maxLength);
                // Even length
                ExpandCenter(input, i, i + 1, ref start, ref maxLength);
            }

            return input.Substring(start, maxLength);
        }

        private void ExpandCenter(string s, int left, int right, ref int start, ref int maxLength)
        {
            while (left >= 0 && right < s.Length && s[left] == s[right])
            {
                int length = right - left + 1;
                if (length > maxLength)
                {
                    maxLength = length;
                    start = left;
                }
                left--;
                right++;
            }
        }
    }
}
