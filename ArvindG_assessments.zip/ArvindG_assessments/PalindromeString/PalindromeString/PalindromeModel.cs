﻿namespace PalindromeString
{
    public class PalindromeModel
    {
        public string? Input { get; set; }
    }
}
