﻿using PalindromeString.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome.Tests.services
{
    public class PalindromeTests
    {
        private readonly PalindromeService _service = new PalindromeService();

        [Fact]
        public void ValidPalindromeString_ReturnsCorrect()
        {
            string input = "babad";
            string result = _service.FindLongestPalindromeString(input);
            Assert.Contains(result, new[] { "bab", "aba" });
        }

        [Fact]
        public void SingleCharacter_Returns()
        {
            string input = "a";
            string result = _service.FindLongestPalindromeString(input);
            Assert.Equal("a", result);
        }

        [Fact]
        public void EmptyInput_ThrowsException()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => _service.FindLongestPalindromeString(""));
        }

        [Fact]
        public void NoPalindrome_ReturnsOneCharacter()
        {
            string input = "abc";
            string result = _service.FindLongestPalindromeString(input);
            Assert.True(result.Length == 1 && input.Contains(result));
        }

        [Fact]
        public void FullPalindrome_ReturnsString()
        {
            string input = "abccba";
            string result = _service.FindLongestPalindromeString(input);
            Assert.Equal("abccba", result);
        }
    }
}
