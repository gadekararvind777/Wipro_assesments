﻿namespace SwapNumber
{
    public class SwapRequest
    {
        public int A { get; set; }
        public int B { get; set; }
    }
}
