﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SwapNumber.Services;

namespace SwapNumber.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SwapNoController : ControllerBase
    {
        private readonly ISwapService _swapService;

        public SwapNoController(ISwapService swapService)
        {
            _swapService = swapService;
        
        }

        [HttpPost]
        public IActionResult Post([FromBody] SwapRequest request)
        {
            try
            {
                var result = _swapService.Swap(request);
                return Ok(result);
            }
            catch (Exception ex) 
            {
                return BadRequest(new { Error = ex.Message });
            }
        }
    }
}
