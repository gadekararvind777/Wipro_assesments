﻿namespace SwapNumber.Services
{
    public interface ISwapService
    {
        public SwapRequest Swap(SwapRequest request);
    }
}
