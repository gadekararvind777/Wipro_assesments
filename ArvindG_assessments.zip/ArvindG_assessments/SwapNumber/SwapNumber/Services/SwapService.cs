﻿namespace SwapNumber.Services
{
    public class SwapService : ISwapService
    {
        public SwapRequest Swap(SwapRequest sr)
        {
            if (sr.A != sr.B)
            {
                sr.A = sr.A + sr.B;
                sr.B = sr.A - sr.B;
                sr.A = sr.A - sr.B;


            }
            return sr;
            
        }
    }
}
