﻿using SwapNumber;
using SwapNumber.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwapNo.Tests.services
{
    public class SwapServiceTests
    {
        private readonly SwapService swapService = new SwapService();
        
        [Fact]
        public void Swap_PositiveNumbers_shouldSwap()
        {
            var input = new SwapRequest { A = 5, B = 7 };
            var output = swapService.Swap(input);
            Assert.Equal(7, output.A);
            Assert.Equal(5, output.B);

        }
        [Fact]
        public void Swap_WithZero_shouldSwap()
        {
            var input = new SwapRequest { A = 0, B = 8 };
            var output = swapService.Swap(input);

            Assert.Equal(8, output.A);
            Assert.Equal(0, output.B);
        }
        [Fact]
        public void Swap_SameNumbers_shouldSwap()
        {
            var input = new SwapRequest { A = 9, B = 9 };
            var output = swapService.Swap(input);

            Assert.Equal(9, output.A);
            Assert.Equal(9, output.B);
        }
        [Fact]
        public void Swap_NegativeNumbers_shouldSwap()
        {
            var input = new SwapRequest { A = -2, B = -7 };
            var output = swapService.Swap(input);

            Assert.Equal(-7, output.A);
            Assert.Equal(-2, output.B);
        }
    }
}
