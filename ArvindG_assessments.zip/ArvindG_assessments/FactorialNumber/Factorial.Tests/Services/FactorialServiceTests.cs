﻿using FactorialNumber.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factorial.Tests.Controllers
{
    public class FactorialServiceTests
    {
        private readonly FactorialService factorialService= new FactorialService();

        [Fact]
        public void Factorial_Of_Zero_Should_Return_One()
        {
            Assert.Equal(1, factorialService.CalculateFactorialNumber(0));
        }

        [Fact]
        public void Factorial_Of_One_Should_Return_One()
        {
            Assert.Equal(1, factorialService.CalculateFactorialNumber(1));
        }

        [Fact]
        public void Factorial_Of_Positive_Number()
        {
            Assert.Equal(120, factorialService.CalculateFactorialNumber(5)); 
        }
        [Fact]
        public void Factorial_Of_Negative_Number_Should_Throw_Exception()
        {
            Assert.Throws<ArgumentException>(() => factorialService.CalculateFactorialNumber(-3));
        }

        [Fact]
        public void Factorial_Of_Larger_Number()
        {
            Assert.Equal(3628800, factorialService.CalculateFactorialNumber(10)); // 10!
        }

        
    }
}
