﻿using FactorialNumber.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FactorialNumber.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FactorialController : ControllerBase
    {

        private readonly IFactorialService _factorialService;

        public FactorialController(IFactorialService factorialService)
        { 
            _factorialService = factorialService;

        }
        [HttpGet("{number}")]
        public IActionResult GetFactorial(int number)
        {
            

                try
                {
                    var result = _factorialService.CalculateFactorialNumber(number);
                    return Ok(new { Number = number, Factorial = result });
                }
                catch (ArgumentException ex)
                {
                    return BadRequest(new { Error = ex.Message });
                }
            
            
        }

    }
}
