﻿namespace FactorialNumber.Services
{
    public interface IFactorialService
    {
        long CalculateFactorialNumber(int number);
    }
}
